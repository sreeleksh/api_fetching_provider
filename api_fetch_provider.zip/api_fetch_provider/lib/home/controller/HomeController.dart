import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:flutter/foundation.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:http/http.dart' as http;

import '../model/PostModel.dart';

class HomeController extends ChangeNotifier {
  var loading = false;
  var postList = <PostModel>[];
  var postModel = PostModel();
  Future<void> fetchPostApi() async {
    var apiUrl = "https://jsonplaceholder.typicode.com/photos";
    final headers = {'Content-Type': 'application/json'};
    try {
      loading = true;
      notifyListeners();
      final response = await http.get(
        Uri.parse(apiUrl),
        headers: headers,
      );
      if (response.statusCode == 200) {
        final List<dynamic> responseData = json.decode(response.body);
        postList =
            responseData.map((element) => PostModel.fromJson(element)).toList();
        notifyListeners();
        Fluttertoast.showToast(msg: "Success to fetch");
      } else if (response.statusCode == 400) {
        Fluttertoast.showToast(msg: "Failed to fetch");
      }
    } catch (e) {
      if (kDebugMode) {
        print("Error $e");
      }
    } finally {
      loading = false;
      notifyListeners();
    }
  }
}
